
# Convert tex to PDF
tools::texi2pdf("RJwrapper.tex")
tools::texi2pdf("RJwrapper.tex")

# Show PDF
system("evince RJwrapper.pdf &")


