library(testthat)
library(regions)

test_check("regions")
