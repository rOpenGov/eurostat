library(testthat)
library(flagr)

test_check("flagr")
