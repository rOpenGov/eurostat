#' @keywords internal
#' @noRd

is.zero <- function(x) {
  x == 0
}
