# potential 0.2.0

## Minor changes
- Change longlat arg default to FALSE in create_matrix()
- Use mapsf instead of cartography in all examples
- Use mapiso instead of isoband
- In epquipotential "xcoords" and "ycoords" are not needed anymore