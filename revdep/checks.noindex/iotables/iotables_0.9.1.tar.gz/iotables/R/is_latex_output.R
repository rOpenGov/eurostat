#' Check if Latex output is required
#'
#' @importFrom knitr is_latex_output
#' @name is_latex_output
NULL