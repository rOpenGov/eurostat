#' Check if HTML output is required
#'
#' @importFrom knitr is_html_output
#' @name is_html_output
NULL