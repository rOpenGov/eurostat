library(testthat)
library(iotables)

test_check("iotables")
