# convergEU

Indicators and measures by country and time describe
what happens at economic and social levels. This package provides
functions to calculate several measures of convergence after imputing
missing values. The automated download of Eurostat data,
followed by the production of country fiches and indicator fiches,
makes possible to  automate the production of reports.

The stable release is available at https://CRAN.R-project.org/package=convergEU
